<link rel="stylesheet" href="../css/admin.css">
<!-- Footer section starts -->
<div class="footer">
        <div class="wrapper">
           <p class="text-center">Developed By - <a href="#">Ameya Raj</a></p>
        </div>
       
    </div>
    <!-- Footer section ends -->
    
    </body>
</html>